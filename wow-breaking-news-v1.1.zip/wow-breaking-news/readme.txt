=== Plugin Name: WoW Breaking News ===
=== Plugin URI: http://www.journeyofashaman.com/wow-breaking-news ===
=== Description: World of Warcraft Breaking News Displaying Widget ===
=== Author: Stoffe Nilsson ===
=== Version: 1.1 ===
=== Author URI: http://www.journeyofashaman.com/ ===

Contributors: Stoffe Nilsson
Donate link: http://donate.journeyofashaman.com/
Tags: World of Warcraft
Requires at least: 2.8
Tested up to: 2.8.3
Stable tag: trunk 

== Description ==

This plugin will let you add a widget on your wordpress site displaying the in-game breaking news that you can se while logging in to World of Warcraft.

== Installation ==

Fast and easy.

1. Extract the downloaded file and copy the 'wow-breaking-news' directory to your plugin directory, like this: `/wp-content/plugins/wow-breaking-news/`. 
2. All files should remain under the 'wow-breaking-news' directory, ie: `/wp-content/plugins/wow-breaking-news/wow-breaking-news.php`
3. Visit the plugin admin page and activate the plugin.
4. Go to the widget admin page and drag it to the sidbar of your choise.
5. Edit the widget settings to customize it for your blog/website.

Done! 

== Frequently Asked Questions ==

None yet...

== Screenshots ==

Comming soon...

== Changelog ==

1.1
- Added widget namechange option
- Inreased the amount of caracters allowed to show in the widget

1.0
- First release